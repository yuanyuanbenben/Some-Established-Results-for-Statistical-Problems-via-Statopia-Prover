
 model = Sequential()
 model.add(Dense(d, activation="relu", input_shape=(d,)))             
 for i in np.arange(L):
    model.add(Dense(K, activation="relu"))
 model.add(Dense(1))
 model.compile(optimizer="adam",
                  loss="mean_squared_error")
 model.fit(x=x_learn,y=y_learn)
   
